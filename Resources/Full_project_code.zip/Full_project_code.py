# ----------------------------------------------------------
# Combined: ESP-NOW sender + HTU21D sensor + DRV8825 stepper
# ----------------------------------------------------------

import network
import espnow
import time
from machine import I2C, Pin

# ----------------------------------------------------------
# DRV8825 CLASS
# ----------------------------------------------------------

class DRV8825:
    # Microstep mode constants
    FULL_STEP = 0
    HALF_STEP = 1
    QUARTER_STEP = 2
    EIGHTH_STEP = 3
    SIXTEENTH_STEP = 4
    THIRTYSECOND_STEP = 5

    # Decay mode constants
    DECAY_SLOW = 0
    DECAY_MIXED = 1
    DECAY_FAST = 2

    def __init__(
        self,
        pin_sleep_reset=15,
        pin_fault=2,
        pin_decay=16,
        pin_dir=13,
        pin_enable=17,
        pin_step=10,
        pin_mode0=4,
        pin_mode1=5,
        pin_mode2=6,
        pin_home=7
    ):

        # Outputs
        self.sleep_reset = Pin(pin_sleep_reset, Pin.OUT, value=0)
        self.decay_pin = Pin(pin_decay, Pin.OUT, value=0)
        self.dir = Pin(pin_dir, Pin.OUT, value=0)
        self.nenbl = Pin(pin_enable, Pin.OUT, value=1)
        self.step_pin = Pin(pin_step, Pin.OUT, value=0)
        self.mode0 = Pin(pin_mode0, Pin.OUT, value=0)
        self.mode1 = Pin(pin_mode1, Pin.OUT, value=0)
        self.mode2 = Pin(pin_mode2, Pin.OUT, value=0)

        # Inputs
        self.fault = Pin(pin_fault, Pin.IN, Pin.PULL_UP)
        self.home = Pin(pin_home, Pin.IN, Pin.PULL_UP)

        # Init
        self.wake()
        self.set_microstep(self.EIGHTH_STEP)
        self.set_decay(self.DECAY_MIXED)
        self.enable()

    def wake(self):
        self.sleep_reset.value(1)
        time.sleep_ms(3)

    def sleep(self):
        self.sleep_reset.value(0)
        self.disable()

    def enable(self):
        self.nenbl.value(0)

    def disable(self):
        self.nenbl.value(1)

    def set_microstep(self, mode):
        mapping = {
            self.FULL_STEP: (0, 0, 0),
            self.HALF_STEP: (0, 0, 1),
            self.QUARTER_STEP: (0, 1, 0),
            self.EIGHTH_STEP: (0, 1, 1),
            self.SIXTEENTH_STEP: (1, 0, 0),
            self.THIRTYSECOND_STEP: (1, 0, 1),
        }
        m0, m1, m2 = mapping[mode]
        self.mode0.value(m0)
        self.mode1.value(m1)
        self.mode2.value(m2)

    def set_decay(self, mode):
        if mode == self.DECAY_SLOW:
            self.decay_pin.init(mode=Pin.OUT)
            self.decay_pin.value(0)
        elif mode == self.DECAY_FAST:
            self.decay_pin.init(mode=Pin.OUT)
            self.decay_pin.value(1)
        elif mode == self.DECAY_MIXED:
            self.decay_pin.init(mode=Pin.IN)
        else:
            raise ValueError("Invalid decay mode")

    def has_fault(self):
        return self.fault.value() == 0

    def at_home(self):
        return self.home.value() == 0

    def step(self, steps, direction=1, step_delay_us=1000):
        self.dir.value(1 if direction > 0 else 0)

        if self.has_fault():
            print("DRV8825 FAULT before stepping!")
            return

        half_delay = max(1, step_delay_us // 2)

        for _ in range(steps):
            self.step_pin.value(1)
            time.sleep_us(half_delay)
            self.step_pin.value(0)
            time.sleep_us(half_delay)

            if self.has_fault():
                print("DRV8825 FAULT during stepping!")
                break


# ----------------------------------------------------------
# HTU21D SENSOR
# ----------------------------------------------------------

HTU21D_ADDR = 0x40
i2c = I2C(0, scl=Pin(22), sda=Pin(21), freq=100000)

def read_htu21d():
    try:
        # Temp
        i2c.writeto(HTU21D_ADDR, b'\xE3')
        time.sleep_ms(50)
        t = i2c.readfrom(HTU21D_ADDR, 3)
        raw_t = ((t[0] << 8) | t[1]) & 0xFFFC
        temp_c = -46.85 + (175.72 * raw_t / 65536)

        # Humidity
        i2c.writeto(HTU21D_ADDR, b'\xE5')
        time.sleep_ms(50)
        h = i2c.readfrom(HTU21D_ADDR, 3)
        raw_h = ((h[0] << 8) | h[1]) & 0xFFFC
        hum = -6 + (125.0 * raw_h / 65536)

        return round(temp_c, 2), round(hum, 2)

    except:
        return None, None


# ----------------------------------------------------------
# ESP-NOW INITIALIZATION
# ----------------------------------------------------------

last_stats_time = time.time()
stats_interval = 10

sta = network.WLAN(network.STA_IF)
sta.active(True)
sta.disconnect()

e = espnow.ESPNow()
e.active(True)

receiver_mac = b'\x68\x25\xdd\x12\x8c\xbc'
e.add_peer(receiver_mac)

def print_stats():
    s = e.stats()
    print("\nESP-NOW Stats")
    print("Sent:", s[0], "Delivered:", s[1], "TX dropped:", s[2])
    print("RX:", s[3], "RX dropped:", s[4])


# ----------------------------------------------------------
# MAIN LOOP — COMBINED
# ----------------------------------------------------------

driver = DRV8825()
direction = 1
message_count = 0

print("System ready.")

while True:
    # --- Read sensor ---
    temp, hum = read_htu21d()
    if temp is None:
        msg = f"ERR Count:{message_count}"
    else:
        msg = f"T:{temp}C H:{hum}% Count:{message_count}"

    # --- Send ESP-NOW ---
    try:
        ok = e.send(receiver_mac, msg, True)
        print("Sent:", msg if ok else "Send failed")
    except:
        print("ESP-NOW error")

    message_count += 1

    # --- Move stepper (non-blocking cycles) ---
    # Move 100 microsteps each loop
    driver.step(100, direction=direction, step_delay_us=1000)

    # Reverse direction every 20 cycles
    if message_count % 20 == 0:
        direction *= -1

    # --- Stats every 10 seconds ---
    if time.time() - last_stats_time > stats_interval:
        print_stats()
        last_stats_time = time.time()

    time.sleep(1)
